"""Demo scene presets for the Script Modeling Guide add-on (same scenes the site used for its Before/After pictures).
Copied from the site build (lib/scenes.py); only clear() and the texture folder differ."""
import bpy, math, os, random

# --- add-on version: every demo is built in a NEW scene; the user's scenes and data are never cleared.
STATE = {"scene": None, "name": "ScriptGuide_Demo", "tex_dir": ""}

def _world():
    w = bpy.data.worlds.new("World")
    try:
        w.use_nodes = True
        bg = w.node_tree.nodes.get("Background")
        if bg: bg.inputs[0].default_value = (0.0508, 0.0508, 0.0508, 1.0)
    except Exception:
        pass
    w.color = (0.0508, 0.0508, 0.0508)
    return w

def objs():
    """objects of the demo scene (setup code must never touch the user's own objects)"""
    sc = STATE["scene"]
    return list(sc.objects) if sc is not None else list(bpy.context.scene.objects)

def obj(name):
    """demo object by its site name. In a file that already has e.g. 'Cube', the demo's cube is 'Cube.001'."""
    import re
    pool = objs()
    for o in pool:
        if o.name == name: return o
    for o in pool:
        if re.match(re.escape(name) + r"\.\d{3}$", o.name): return o
    return bpy.data.objects[name]

def clear():
    """first call: make + show a fresh demo scene (factory-like). later calls (presets that rebuild): empty that demo scene only."""
    sc = STATE["scene"]
    if sc is None:
        sc = bpy.data.scenes.new(STATE["name"]); STATE["scene"] = sc
        sc.world = _world()
        bpy.context.window.scene = sc
    else:
        for o in list(sc.objects): bpy.data.objects.remove(o, do_unlink=True)
        for c in list(sc.collection.children): bpy.data.collections.remove(c)
    c = bpy.data.collections.new("Collection"); sc.collection.children.link(c)
    vl = bpy.context.view_layer; vl.active_layer_collection = vl.layer_collection.children[c.name]

def mat(name, rgb, metal=0.0, rough=0.5):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    try: m.use_nodes = True
    except Exception: pass
    b = m.node_tree.nodes.get("Principled BSDF")
    if b:
        b.inputs["Base Color"].default_value = (*rgb, 1); b.inputs["Metallic"].default_value = metal; b.inputs["Roughness"].default_value = rough
    m.diffuse_color = (*rgb, 1)
    return m

def add(kind, loc=(0, 0, 0), name=None, **kw):
    ops = {"cube": bpy.ops.mesh.primitive_cube_add, "sphere": bpy.ops.mesh.primitive_uv_sphere_add, "ico": bpy.ops.mesh.primitive_ico_sphere_add,
           "cyl": bpy.ops.mesh.primitive_cylinder_add, "cone": bpy.ops.mesh.primitive_cone_add, "torus": bpy.ops.mesh.primitive_torus_add,
           "monkey": bpy.ops.mesh.primitive_monkey_add, "plane": bpy.ops.mesh.primitive_plane_add, "grid": bpy.ops.mesh.primitive_grid_add}
    ops[kind](location=loc, **kw)
    o = bpy.context.active_object
    if name: o.name = name; o.data.name = name
    return o

def ground(size=14):
    p = add("plane", (0, 0, 0), "Ground", size=size); p.data.materials.append(mat("GroundMat", (0.35, 0.35, 0.36), rough=0.8)); return p

def deselect():
    for o in bpy.context.view_layer.objects: o.select_set(False)

def sel(objs, active=None):
    deselect()
    for o in objs: o.select_set(True)
    bpy.context.view_layer.objects.active = active or (objs[0] if objs else None)

GREY = (0.6, 0.6, 0.6)

def S_mixed():
    """6 primitives, default names, all selected."""
    clear(); random.seed(3)
    objs = [add("cube", (-3, 0, 1)), add("sphere", (0, 0, 1)), add("cyl", (3, 0, 1)), add("cone", (-3, 3, 1)), add("torus", (0, 3, 0.25)), add("monkey", (3, 3, 1))]
    sel(objs, objs[0]); return objs

def S_messy():
    """objects with messy names/rotation/scale/heights, all selected."""
    clear(); random.seed(5); objs = []
    kinds = ["cube", "sphere", "cyl", "cone", "monkey", "ico"]
    for i, k in enumerate(kinds):
        o = add(k, (random.uniform(-4, 4), random.uniform(-3, 3), random.uniform(0.5, 3)))
        o.rotation_euler = [random.uniform(-0.6, 0.6) for _ in range(3)]
        s = random.uniform(0.5, 1.4); o.scale = (s, s * random.uniform(0.8, 1.3), s)
        objs.append(o)
    names = ["Cube.001 ", "  sphere_final_FINAL", "Cylinder.003", "cone copy.002", "Suzanne.001", "Icosphere.012"]
    for o, n in zip(objs, names): o.name = n
    sel(objs, objs[0]); return objs

def S_row():
    clear(); objs = []
    for i, k in enumerate(["cube", "sphere", "cyl", "cone", "monkey"]):
        o = add(k, (i * 1.7 - 3.4 + [0, .6, -.4, .3, 0][i], [0, 1.2, -.8, .5, -1.1][i], [1, 2.2, 1.6, 0.4, 2.8][i])); objs.append(o)
    sel(objs, objs[0]); return objs

def S_single(kind="cube", **kw):
    clear(); o = add(kind, (0, 0, 1), **kw); sel([o]); return [o]

def S_cube(): return S_single("cube")
def S_monkey(): return S_single("monkey")
def S_sphere(): return S_single("sphere")

def S_lowpoly():
    clear(); objs = [add("cube", (-2.5, 0, 1)), add("monkey", (0, 0, 1)), add("cyl", (2.5, 0, 1))]
    for o in objs: o.data.materials.append(mat("Grey", GREY))
    sel(objs); return objs

def S_studio():
    """a monkey on a ground with a camera, no lights (for lighting scripts)"""
    clear(); g = ground(20)
    m = add("monkey", (0, 0, 1), "Suzanne"); m.data.materials.append(mat("Clay", (0.8, 0.55, 0.4), rough=0.45))
    m.data.shade_smooth() if hasattr(m.data, "shade_smooth") else None
    mod = m.modifiers.new("Subd", "SUBSURF"); mod.levels = 2; mod.render_levels = 2
    s = add("sphere", (2.2, -0.5, 0.6), "Ball"); s.scale = (0.6,) * 3; s.data.materials.append(mat("Blue", (0.15, 0.3, 0.8), rough=0.3)); s.data.shade_smooth()
    c = add("cube", (-2.2, 0.3, 0.5), "Box"); c.scale = (0.5,) * 3; c.data.materials.append(mat("Yellow", (0.9, 0.7, 0.1)))
    bpy.ops.object.camera_add(location=(0, -8.5, 3.2), rotation=(math.radians(78), 0, 0)); cam = bpy.context.active_object; cam.name = "Camera"
    bpy.context.scene.camera = cam
    sel([m], m); return [g, m, s, c, cam]

def S_studio_lit():
    objs = S_studio()
    bpy.ops.object.light_add(type="AREA", location=(3, -3, 5)); l = bpy.context.active_object; l.data.energy = 600; l.data.size = 3
    l.rotation_euler = (math.radians(40), 0, math.radians(45))
    bpy.ops.object.light_add(type="POINT", location=(-4, -2, 3)); l2 = bpy.context.active_object; l2.data.energy = 300
    sel([objs[1]]); return objs + [l, l2]

def S_cameras():
    objs = S_studio_lit()
    cams = [o for o in objs if o.type == "CAMERA"]
    for i, (loc, rot) in enumerate([((6, -6, 4), (63, 0, 45)), ((-7, -4, 2), (82, 0, -60)), ((0, 0, 10), (0, 0, 0))]):
        bpy.ops.object.camera_add(location=loc, rotation=[math.radians(a) for a in rot]); c = bpy.context.active_object; c.name = ["Cam_Front", "Cam_Side", "Cam_Top"][i]
    cams[0].name = "Cam_Main"
    deselect(); return objs

def S_unused():
    clear()
    o = add("cube", (0, 0, 1), "Box"); o.data.materials.append(mat("Used_Red", (0.8, 0.1, 0.1)))
    for n in ["Old_Metal", "Test.001", "Material.004", "unused_glass"]: mat(n, (0.5, 0.5, 0.5))
    for i in range(3): bpy.data.meshes.new("orphan_mesh.%03d" % i)
    bpy.data.images.new("old_render", 64, 64); bpy.data.images.new("Untitled", 32, 32)
    sel([o]); return [o]

def S_hidden():
    objs = S_mixed()
    for o in objs[1::2]: o.hide_set(True)
    objs[2].hide_viewport = True
    objs[4].hide_render = True
    deselect(); return objs

def S_dup_mats():
    clear(); objs = []
    for i in range(6):
        o = add(["cube", "sphere", "cyl"][i % 3], ((i % 3) * 2.5 - 2.5, (i // 3) * 2.5, 1))
        m = mat("Wood" if i == 0 else "Wood.%03d" % i, (0.55, 0.33, 0.15)) if i % 2 == 0 else mat("Steel" if i == 1 else "Steel.%03d" % i, (0.7, 0.7, 0.75), metal=1)
        o.data.materials.append(m); objs.append(o)
    sel(objs); return objs

def S_collections():
    clear(); random.seed(1); objs = []
    for i in range(4): objs.append(add(["cube", "sphere", "cyl", "cone"][i], (i * 2.2 - 3.3, 0, 1)))
    for i in range(2):
        bpy.ops.object.light_add(type="POINT", location=(i * 4 - 2, -3, 4)); objs.append(bpy.context.active_object)
    bpy.ops.object.camera_add(location=(0, -10, 4), rotation=(math.radians(75), 0, 0)); objs.append(bpy.context.active_object)
    bpy.ops.object.empty_add(location=(0, 3, 1)); objs.append(bpy.context.active_object)
    for n in ["Empty_Coll", "Old_Stuff", "temp"]:
        bpy.context.scene.collection.children.link(bpy.data.collections.new(n))
    sel(objs[:4]); return objs

def S_grid_plane():
    clear(); p = add("plane", (0, 0, 0), "Ground", size=10); p.data.materials.append(mat("Grass", (0.2, 0.45, 0.15)))
    t = add("cone", (0, 0, 0.75), "Tree", vertices=8, radius1=0.4, depth=1.5); t.data.materials.append(mat("Leaf", (0.1, 0.35, 0.12)))
    t.location = (0, 0, 0.75)
    sel([t], t); return [p, t]

def S_terrain_plane():
    clear(); p = add("grid", (0, 0, 0), "Terrain", x_subdivisions=80, y_subdivisions=80, size=10); p.data.materials.append(mat("Earth", (0.35, 0.45, 0.2)))
    sel([p]); return [p]

def S_empty():
    clear(); return []

def S_broken_normals():
    clear(); import bmesh
    objs = [add("cube", (-2, 0, 1)), add("monkey", (1.5, 0, 1))]
    for o in objs:
        bm = bmesh.new(); bm.from_mesh(o.data)
        for i, f in enumerate(bm.faces):
            if i % 2 == 0: f.normal_flip()
        # duplicate verts: split some edges
        bmesh.ops.split_edges(bm, edges=bm.edges[:len(bm.edges)//3])
        bm.to_mesh(o.data); bm.free()
    sel(objs); return objs

def S_textured():
    """3 objects whose image textures point to a moved folder"""
    clear(); base = bpy.path.abspath("//")
    new = os.path.join(base, "textures_new"); os.makedirs(new, exist_ok=True)
    import array
    cols = {"brick": ((0.6, 0.2, 0.1), (0.85, 0.8, 0.75)), "checker": ((0.1, 0.1, 0.1), (0.9, 0.9, 0.9)), "stripes": ((0.1, 0.3, 0.7), (0.95, 0.8, 0.2))}
    objs = []
    for i, (nm, (a, b)) in enumerate(cols.items()):
        img = bpy.data.images.new(nm, 128, 128); px = []
        for y in range(128):
            for x in range(128):
                if nm == "brick": on = (y // 16) % 2 == 0 and True; on = ((x + (8 if (y // 16) % 2 else 0) * 2) % 32 < 29) and (y % 16 < 14)
                elif nm == "checker": on = ((x // 16) + (y // 16)) % 2 == 0
                else: on = (x // 12) % 2 == 0
                c = a if on else b; px += [c[0], c[1], c[2], 1]
        img.pixels = px; img.filepath_raw = os.path.join(new, nm + ".png"); img.file_format = "PNG"; img.save()
        bpy.data.images.remove(img)
        o = add(["cube", "sphere", "cyl"][i], (i * 2.6 - 2.6, 0, 1), nm.capitalize() + "_Obj")
        if o.type == "MESH" and nm != "brick": o.data.shade_smooth()
        m = bpy.data.materials.new(nm + "_mat")
        try: m.use_nodes = True
        except Exception: pass
        nt = m.node_tree; t = nt.nodes.new("ShaderNodeTexImage")
        im = bpy.data.images.load(os.path.join(new, nm + ".png")); im.filepath = "D:/old_project/textures/" + nm + ".png"; im.reload()
        t.image = im; nt.links.new(t.outputs["Color"], nt.nodes["Principled BSDF"].inputs["Base Color"])
        o.data.materials.append(m); objs.append(o)
    sel(objs); return objs

def S_csv():
    clear(); base = bpy.path.abspath("//")
    rows = ["frame,x,y,z"] + ["%d,%.3f,%.3f,%.3f" % (f, math.cos(f / 12) * 3, math.sin(f / 12) * 3, 0.5 + abs(math.sin(f / 6)) * 2) for f in range(1, 76, 5)]
    open(os.path.join(base, "drone_log.csv"), "w").write("\n".join(rows) + "\n")
    ground(12); o = add("ico", (0, 0, 1), "Drone", radius=0.35); o.data.materials.append(mat("Orange", (0.9, 0.35, 0.05)))
    sel([o]); return [o]

def S_import_folder():
    clear(); base = bpy.path.abspath("//"); d = os.path.join(base, "models"); os.makedirs(d, exist_ok=True)
    for k in ["monkey", "torus", "cone", "ico"]:
        o = add(k, (0, 0, 0), k.capitalize())
        sel([o]); bpy.ops.wm.obj_export(filepath=os.path.join(d, k + ".obj"), export_selected_objects=True, export_materials=False)
        bpy.data.objects.remove(o, do_unlink=True)
    clear(); ground(14); return []

def S_anim_cubes():
    clear(); objs = []
    for i in range(6):
        o = add("cube", (i * 1.5 - 3.75, 0, 0.5), "Bar_%d" % i, size=1); objs.append(o)
        o.data.materials.append(mat("Teal", (0.1, 0.55, 0.6)))
    sel(objs); return objs

def S_keyed():
    objs = S_mixed()
    sc = bpy.context.scene
    for i, o in enumerate(objs):
        o.keyframe_insert("location", frame=1); o.location.z += 2 + i * 0.3; o.keyframe_insert("location", frame=40 + i * 10)
        o.keyframe_insert("rotation_euler", frame=1); o.rotation_euler.z += 3.14; o.keyframe_insert("rotation_euler", frame=60)
    sc.frame_end = 250; sc.frame_set(1)
    sel(objs); return objs

def S_curve_path():
    clear(); ground(14)
    bpy.ops.curve.primitive_bezier_circle_add(radius=4, location=(0, 0, 0.6)); c = bpy.context.active_object; c.name = "Track"
    c.data.splines[0].bezier_points[0].co.x += 1.5; c.data.splines[0].bezier_points[0].handle_left.x += 1.5; c.data.splines[0].bezier_points[0].handle_right.x += 1.5
    o = add("cube", (0, 0, 0.6), "Car", size=0.8); o.scale = (1.6, 0.8, 0.6); o.data.materials.append(mat("Red", (0.8, 0.05, 0.05)))
    sel([o], o); return [c, o]

def S_highpoly():
    clear(); objs = []
    m = add("monkey", (-2.2, 0, 1), "Suzanne_HD"); md = m.modifiers.new("S", "SUBSURF"); md.levels = 3
    s = add("sphere", (2.2, 0, 1), "Sphere_HD", segments=96, ring_count=48)
    sel([m, s], m); return [m, s]


def S_pbr_folder():
    """object + a folder //textures/Bricks072 with CC0 ambientCG maps"""
    import shutil
    clear(); base = bpy.path.abspath("//"); d = os.path.join(base, "textures", "Bricks072"); os.makedirs(d, exist_ok=True)
    src = os.path.join(STATE["tex_dir"], "Bricks072")
    for f in os.listdir(src):
        if "displacement" in f: continue
        shutil.copy(os.path.join(src, f), os.path.join(d, f.replace("acg_", "")))
    o = add("cube", (0, 0, 1), "Wall", size=2); o.scale = (1.6, 0.25, 1); bpy.ops.object.transform_apply(scale=True)
    s = add("sphere", (2.4, 0, 1), "Ball"); s.data.shade_smooth()
    sel([o, s], o); return [o, s]

def S_gears():
    clear(); objs = []
    for i, (x, r, n) in enumerate([(0, 1.0, 16), (1.95, 0.8, 12)]):
        bpy.ops.mesh.primitive_cylinder_add(vertices=n * 2, radius=r, depth=0.3, location=(x, 0, 0.15))
        o = bpy.context.active_object; o.name = "Gear_%s" % "AB"[i]
        import bmesh
        bm = bmesh.new(); bm.from_mesh(o.data)
        for v in bm.verts:
            ang = math.atan2(v.co.y, v.co.x); k = round(ang / (math.pi / n))
            if k % 2 == 0: v.co.x *= 1.15; v.co.y *= 1.15
        bm.to_mesh(o.data); bm.free()
        o.data.materials.append(mat("Brass" if i == 0 else "Steel", (0.8, 0.6, 0.2) if i == 0 else (0.6, 0.62, 0.66), metal=1, rough=0.3))
        objs.append(o)
    sel(objs, objs[0]); return objs

def S_stage():
    """ground + camera + two lights, nothing else selected (for scripts that build things or render)"""
    clear(); g = ground(30)
    bpy.ops.object.camera_add(location=(0, -15, 6.5), rotation=(math.radians(70), 0, 0)); cam = bpy.context.active_object; cam.name = "Camera"
    bpy.context.scene.camera = cam
    bpy.ops.object.light_add(type="AREA", location=(4, -5, 7)); l = bpy.context.active_object; l.data.energy = 1500; l.data.size = 5
    l.rotation_euler = (math.radians(35), 0, math.radians(35))
    bpy.ops.object.light_add(type="POINT", location=(-6, -3, 4)); l2 = bpy.context.active_object; l2.data.energy = 600
    deselect(); return [g, cam, l, l2]

def S_stage_mixed():
    """the 6 primitives of 'mixed' (colored, all selected) on the stage"""
    st = S_stage(); random.seed(3)
    objs = [add("cube", (-3, 0, 1)), add("sphere", (0, 0, 1)), add("cyl", (3, 0, 1)), add("cone", (-3, 3, 1)), add("torus", (0, 3, 0.25)), add("monkey", (3, 3, 1))]
    cols = [(0.8, 0.25, 0.15), (0.15, 0.45, 0.8), (0.9, 0.7, 0.15), (0.3, 0.65, 0.3), (0.65, 0.3, 0.7), (0.85, 0.55, 0.4)]
    for o, c in zip(objs, cols): o.data.materials.append(mat("Mat_" + o.name, c, rough=0.45))
    sel(objs, objs[0]); return st + objs


SCENES = {k[2:]: v for k, v in globals().items() if k.startswith("S_")}
