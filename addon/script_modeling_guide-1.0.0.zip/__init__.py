# -*- coding: utf-8 -*-
# 블렌더 스크립트 & 모델링 가이드 — 예제 만들기 애드온 v1.0 / Blender Script & Modeling Guide — example builder add-on v1.0
# 가이드 사이트(https://kibang.github.io/blender-script-guide/)의 모든 예제를 3D 뷰 사이드바에서 골라 버튼 한 번으로 만들고,
# 사이트의 '코드 복사' 버튼으로 복사한 코드를 [클립보드에서 붙여넣어 만들기]로 바로 실행합니다.
# Every example of the guide site can be picked in the 3D View sidebar and built in one click; code copied with the
# site's copy buttons runs with [Paste from Clipboard & Build].
# 설치/Install: Edit > Preferences > Get Extensions (또는 Add-ons) > ▾ > Install from Disk... > 이 zip (Blender 4.2 ~ 5.3)
# 사용/Use: 3D Viewport > N > '스크립트 가이드' (Script Guide) 탭
bl_info = {
    "name": "스크립트 모델링 가이드 (Script Modeling Guide)",
    "author": "블렌더 스크립트 & 모델링 가이드",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "3D Viewport > N 사이드바 > 스크립트 가이드 / Script Guide",
    "description": "가이드 사이트의 예제를 버튼 하나로 만들고, 복사한 코드를 붙여넣어 실행합니다 / Build the guide's examples and run copied code",
    "category": "3D View",
}

import bpy, os, sys, json, ast, io, re, time, hashlib, linecache, tempfile, traceback, textwrap, unicodedata, contextlib

HERE = os.path.dirname(os.path.abspath(__file__))
_DATA = None
_BY_ID = {}
_BY_HASH = {}
LAST = {}              # last build result (also read by the headless test)


def data():
    global _DATA
    if _DATA is None:
        with open(os.path.join(HERE, "bsg_data.json"), encoding="utf-8") as f:
            _DATA = json.load(f)
        try:
            with open(os.path.join(HERE, "compat.json"), encoding="utf-8") as f:
                comp = json.load(f)
        except Exception:
            comp = {}
        for e in _DATA["examples"]:
            e["compat"] = comp.get(e["id"])
            _BY_ID[e["id"]] = e
            _BY_HASH[e["hash"]] = e
    return _DATA


# ------------------------------------------------------------------ language (Korean / English)
def _addon_prefs():
    for key in (__package__, __name__):
        try:
            if key:
                return bpy.context.preferences.addons[key].preferences
        except Exception:
            pass
    return None


def _lang():
    pr = _addon_prefs()
    ch = getattr(pr, "ui_language", "AUTO") if pr is not None else "AUTO"
    if ch in ("KO", "EN"):
        return ch
    try:
        v = bpy.context.preferences.view
        loc = bpy.app.translations.locale or ""
        if loc.startswith("ko") and getattr(v, "use_translate_interface", True):
            return "KO"
        if loc and not loc.startswith(("en", "C")):
            return "EN"
    except Exception:
        pass
    return "EN"


def _t(ko, en):
    return ko if _lang() == "KO" else en


def _pick(e, k):
    return (e.get(k) if _lang() == "KO" else e.get({"ko": "en", "dko": "den"}.get(k, k))) or e.get(k) or ""


KIND = {"script": ("스크립트", "Scripts"), "model": ("모델링 예제", "Modeling"), "start": ("시작 타입", "Start types")}
METHOD = {"basic": ("기본 모델링", "Basic modeling"), "modifier": ("모디파이어", "Modifiers")}


def ex_title(e, short=False):
    t = _pick(e, "ko")
    if e["kind"] == "model":
        t += " · " + _t(*METHOD[e["method"]])
    if e["kind"] == "script" and not short:
        t = e["id"][1:] + "  " + t
    return t


def cat_label(c):
    lab = data()["cat_labels"].get(c)
    return _t(lab[0], lab[1]) if lab else c


# ------------------------------------------------------------------ clips (exactly what the site's copy buttons copy)
def norm(code):
    return "\n".join(l.rstrip() for l in code.replace("\r\n", "\n").replace("\r", "\n").strip("\n").split("\n"))


def clip_of(e):
    D = data()
    if e["kind"] == "model":
        return D["prelude"] + D["model_glue"] + e["code"]
    if e["kind"] == "start":
        return D["start_prelude"] + D["start_glue"] + e["code"]
    return e["code"]


def match_clip(text):
    data()
    return _BY_HASH.get(hashlib.sha1(norm(text).encode("utf-8")).hexdigest())


def guess_kind(text):
    """for edited / unknown code: does it start with one of the site's helper preludes?"""
    D = data(); n = norm(text)
    if n.startswith(norm(D["prelude"])[:400]):
        return "model"
    if n.startswith(norm(D["start_prelude"])[:400]):
        return "start"
    return "code"


def version_block(e):
    """None, or (reason ko, reason en) when this example cannot run in this Blender version."""
    c = e.get("compat") or {}
    mn = c.get("min")
    if mn and bpy.app.version < tuple(mn):
        return c.get("why") or ("Blender %d.%d 이상 전용 기능을 써요" % tuple(mn[:2]), "uses features of Blender %d.%d+" % tuple(mn[:2]))
    return None


# ------------------------------------------------------------------ static check of pasted code (no execution)
RISKY_MODULES = {"os": "file", "shutil": "file", "pathlib": "file", "subprocess": "system", "sys": "system", "ctypes": "system",
                 "socket": "net", "urllib": "net", "requests": "net", "http": "net", "ftplib": "net", "smtplib": "net", "webbrowser": "net",
                 "importlib": "system", "pickle": "system", "marshal": "system", "multiprocessing": "system", "threading": "system"}
RISKY_CALLS = {"eval": "system", "exec": "system", "compile": "system", "__import__": "system", "open": "file"}
RISKY_ATTRS = {"remove": "file", "unlink": "file", "rmdir": "file", "rmtree": "file", "removedirs": "file", "rename": "file", "replace": "file",
               "system": "system", "popen": "system", "Popen": "system", "run": None, "call": "system", "check_output": "system",
               "save_mainfile": "blend", "save_as_mainfile": "blend", "open_mainfile": "blend", "read_homefile": "blend",
               "read_factory_settings": "blend", "quit_blender": "blend", "revert_mainfile": "blend", "addon_install": "prefs",
               "addon_enable": "prefs", "addon_remove": "prefs", "package_install": "prefs", "package_install_files": "prefs",
               "save_userpref": "prefs", "url_open": "net", "urlopen": "net", "write_bytes": "file", "write_text": "file", "makedirs": "file"}
RISK_TXT = {"file": ("파일을 읽거나 쓰거나 지울 수 있어요", "can read, write or delete files"),
            "system": ("다른 프로그램·파이썬 기능을 직접 실행할 수 있어요", "can run other programs or dynamic Python"),
            "net": ("인터넷에 연결할 수 있어요", "can connect to the internet"),
            "blend": (".blend 파일을 저장·열기·닫기할 수 있어요", "can save, open or close .blend files"),
            "prefs": ("애드온·환경설정을 바꿀 수 있어요", "can change add-ons or preferences"),
            "data": ("이 파일 전체의 데이터를 바꾸거나 지워요 (다른 씬 포함)", "changes or deletes data in the whole file (other scenes too)"),
            "render": ("렌더를 해요 (시간이 걸릴 수 있어요)", "renders (may take a while)")}


def scan(code):
    """-> dict(ok, error, line, risks{kind: [(line, what)]}, lines). Never executes the code."""
    out = {"ok": True, "error": "", "line": 0, "risks": {}, "lines": code.count("\n") + 1}
    try:
        tree = ast.parse(code)
    except SyntaxError as ex:
        out.update(ok=False, error=ex.msg, line=ex.lineno or 0)
        return out
    def add(k, ln, what):
        if k: out["risks"].setdefault(k, []).append((ln, what))
    for n in ast.walk(tree):
        ln = getattr(n, "lineno", 0)
        if isinstance(n, (ast.For, ast.comprehension)):
            it = ast.unparse(n.iter) if hasattr(ast, "unparse") else ""
            if re.match(r"^(list|sorted|tuple)?\(?bpy\.data\.(objects|meshes|materials|collections|images|textures|node_groups|actions|cameras|lights|curves|worlds|scenes)\b", it):
                add("data", ln, "for … in " + it[:60])
        if isinstance(n, ast.Import):
            for a in n.names:
                add(RISKY_MODULES.get(a.name.split(".")[0]), ln, "import " + a.name)
        elif isinstance(n, ast.ImportFrom) and n.module:
            add(RISKY_MODULES.get(n.module.split(".")[0]), ln, "from " + n.module)
        elif isinstance(n, ast.Call):
            f = n.func
            if isinstance(f, ast.Name) and f.id in RISKY_CALLS:
                if f.id == "open":
                    mode = ""
                    if len(n.args) > 1 and isinstance(n.args[1], ast.Constant): mode = str(n.args[1].value)
                    for kw in n.keywords:
                        if kw.arg == "mode" and isinstance(kw.value, ast.Constant): mode = str(kw.value.value)
                    add("file", ln, "open(..., '%s')" % (mode or "r"))
                else:
                    add(RISKY_CALLS[f.id], ln, f.id + "()")
            elif isinstance(f, ast.Attribute):
                k = RISKY_ATTRS.get(f.attr)
                src = ast.unparse(f) if hasattr(ast, "unparse") else f.attr
                if f.attr == "run" and "subprocess" in src: k = "system"
                if f.attr in ("remove", "replace", "rename") and not src.startswith(("os.", "shutil.", "pathlib")): k = None
                if f.attr in ("render",) and "bpy.ops.render" in src: k = "render"
                if f.attr == "remove" and src.startswith("bpy.data."): k = "data"
                if f.attr in ("orphans_purge",): k = "data"
                add(k, ln, src + "()")
    return out


def risk_lines(sc, limit=6):
    rows = []
    for k, lst in sc["risks"].items():
        lines = sorted({l for l, _ in lst})
        rows.append("• " + _t(*RISK_TXT[k]) + "  (" + _t("줄 ", "line ") + ", ".join(str(l) for l in lines[:6]) + ("…" if len(lines) > 6 else "") + ")")
    return rows[:limit]


# ------------------------------------------------------------------ Blender 4.x compatibility (site code is written for 5.3)
class _Compat45(ast.NodeTransformer):
    """4.x: bpy.data.materials.new()/worlds.new() return data without a node tree (5.x always has one) -> switch nodes on."""
    def visit_Call(self, node):
        self.generic_visit(node)
        f = node.func
        if isinstance(f, ast.Attribute) and f.attr == "new" and isinstance(f.value, ast.Attribute) and f.value.attr in ("materials", "worlds"):
            return ast.copy_location(ast.Call(func=ast.Name(id="__bsg_nodes_on", ctx=ast.Load()), args=[node], keywords=[]), node)
        return node


def _nodes_on(idb):
    try:
        if getattr(idb, "node_tree", 1) is None or not getattr(idb, "use_nodes", True):
            idb.use_nodes = True
    except Exception:
        pass
    return idb


def compile_for_this_blender(code, filename):
    if bpy.app.version >= (5, 0, 0):
        return compile(code, filename, "exec"), False
    tree = ast.parse(code, filename)
    new = ast.fix_missing_locations(_Compat45().visit(tree))
    changed = "__bsg_nodes_on" in ast.dump(new)
    return compile(new, filename, "exec"), changed



# ------------------------------------------------------------------ Solid-mode visibility (Workbench / Solid viewport shows material.diffuse_color)
_COLOR_SOCKETS = ("Base Color", "Color", "Emission Color")


def _shader_color(mat):
    """colour of the shader that feeds the Material Output (unlinked colour input), or None."""
    nt = getattr(mat, "node_tree", None)
    if nt is None:
        return None
    out = next((n for n in nt.nodes if n.bl_idname == "ShaderNodeOutputMaterial" and getattr(n, "is_active_output", True)), None) or \
        next((n for n in nt.nodes if n.bl_idname == "ShaderNodeOutputMaterial"), None)
    start = out.inputs[0].links[0].from_node if out and out.inputs and out.inputs[0].is_linked else None
    seen, todo = set(), [start] if start else [n for n in nt.nodes if n.bl_idname == "ShaderNodeBsdfPrincipled"][:1]
    while todo:
        n = todo.pop(0)
        if n is None or n.name in seen: continue
        seen.add(n.name)
        for nm in _COLOR_SOCKETS:
            sk = n.inputs.get(nm)
            if sk is not None and not sk.is_linked and hasattr(sk, "default_value"):
                try:
                    v = tuple(sk.default_value)
                    if len(v) >= 3: return (v[0], v[1], v[2], 1.0), n
                except TypeError:
                    pass
        for sk in n.inputs:                      # Mix / Add shader: follow linked shader inputs
            if sk.is_linked and sk.type == "SHADER": todo.append(sk.links[0].from_node)
    return None


def solid_colors(new_mats):
    """Materials made by the example that still have the default viewport colour get their shader colour,
    so the result looks right in Solid mode / Workbench (the site rendered with Cycles/EEVEE)."""
    n = 0
    for m in new_mats:
        try:
            if tuple(round(x, 4) for x in m.diffuse_color) != (0.8, 0.8, 0.8, 1.0):
                continue                                   # the code chose its own viewport colour
            sc = _shader_color(m)
            if not sc:
                continue
            col, node = sc
            if tuple(round(x, 4) for x in col) == (0.8, 0.8, 0.8, 1.0):
                continue
            m.diffuse_color = col
            if node.bl_idname == "ShaderNodeBsdfPrincipled":
                for a, b in (("Metallic", "metallic"), ("Roughness", "roughness")):
                    sk = node.inputs.get(a)
                    if sk is not None and not sk.is_linked:
                        setattr(m, b, float(sk.default_value))
            n += 1
        except Exception:
            pass
    return n

# ------------------------------------------------------------------ building
def _demo_module():
    from . import demo_scenes
    return demo_scenes


def _workdir(sub=""):
    """folder that "//" means while the example runs: the .blend folder, or (unsaved file) a temp folder per example."""
    if bpy.data.filepath:
        return os.path.dirname(bpy.path.abspath(bpy.data.filepath)), False
    d = os.path.join(tempfile.gettempdir(), "blender_script_guide", re.sub(r"[^A-Za-z0-9_.-]", "_", sub) if sub else "")
    os.makedirs(d, exist_ok=True)
    return d, True


def _list_files(d, depth=3, cap=4000):
    out = {}
    base = d.rstrip(os.sep).count(os.sep)
    for root, dirs, files in os.walk(d):
        if root.count(os.sep) - base >= depth: dirs[:] = []
        for f in files:
            p = os.path.join(root, f)
            try: out[p] = os.path.getmtime(p)
            except OSError: pass
            if len(out) >= cap: return out
    return out


def _view3d(context):
    win = context.window or (context.window_manager.windows[0] if context.window_manager.windows else None)
    if win is None:
        return None, None, None
    area = context.area if context.area is not None and context.area.type == "VIEW_3D" else None
    if area is None:
        area = next((a for a in win.screen.areas if a.type == "VIEW_3D"), None)
    reg = next((r for r in area.regions if r.type == "WINDOW"), None) if area else None
    return win, area, reg


class _Tee(io.TextIOBase):
    def __init__(self, real):
        self.real, self.buf = real, []
    def write(self, s):
        self.buf.append(s)
        try: self.real.write(s)
        except Exception: pass
        return len(s)
    def flush(self):
        try: self.real.flush()
        except Exception: pass


def _obj_mode(context):
    if context.mode != "OBJECT":
        try:
            bpy.ops.object.mode_set(mode="OBJECT")
        except Exception:
            pass


def build(context, code, ex=None, kind=None, use_demo=True, label=None):
    """Run site code safely. kind: script | model | start | code. Returns result dict (also stored in LAST)."""
    kind = kind or (ex["kind"] if ex else "code")
    name = ex["id"] if ex else "pasted"
    res = {"id": name, "kind": kind, "ok": False, "msg": "", "error": "", "line": 0, "output": [], "new_objects": 0,
           "scene": "", "collection": "", "files": [], "workdir": "", "compat": False, "seconds": 0.0, "known": ex is not None}
    t0 = time.time()
    prefs_view = context.preferences.view
    keep_newdata = getattr(prefs_view, "use_translate_new_dataname", False)
    win, area, reg = _view3d(context)
    if win is None or area is None:
        res["error"] = _t("3D 뷰포트가 있는 창에서 실행해 주세요.", "Run this from a window that has a 3D Viewport.")
        LAST.clear(); LAST.update(res); return res
    old_cwd = os.getcwd()
    wd, is_tmp = _workdir(name); res["workdir"] = wd
    files_before = _list_files(wd)
    orig_scene = win.scene
    created_scene = None; created_coll = None
    before = {o.as_pointer() for o in bpy.data.objects}
    mats_before = {m.as_pointer() for m in bpy.data.materials}
    fname = "<%s>" % (("Script Guide " + name) if ex else "pasted code")
    lines = code.splitlines(True)
    linecache.cache[fname] = (len(code), None, lines, fname)
    tee_out = _Tee(sys.stdout)
    ns = {"__name__": "__main__", "__file__": fname, "__bsg_nodes_on": _nodes_on}
    stage = "setup"
    try:
        prefs_view.use_translate_new_dataname = False      # site code expects English data names (Cube, Suzanne ...)
        os.chdir(wd)                                        # "//" in an unsaved file = current folder
        with context.temp_override(window=win, area=area, region=reg, screen=win.screen):
            _obj_mode(bpy.context)
            if kind == "script" and ex and use_demo and ex.get("setup"):
                dm = _demo_module()
                dm.STATE.update(scene=None, name=("ScriptGuide_" + name)[:60], tex_dir=os.path.join(HERE, "textures"))
                dm.SCENES[ex["setup"]]()
                created_scene = dm.STATE["scene"]
                if ex.get("setup_extra"):
                    sys.modules["scenes"] = dm
                    try:
                        exec(compile_for_this_blender(ex["setup_extra"], "<demo setup>")[0], {"__name__": "setup", "scenes": dm, "__bsg_nodes_on": _nodes_on})
                    finally:
                        sys.modules.pop("scenes", None)
                bpy.context.view_layer.update()
                res["scene"] = created_scene.name if created_scene else ""
            else:
                sc = bpy.context.scene
                created_coll = bpy.data.collections.new(("ScriptGuide " + (label or name))[:60])
                sc.collection.children.link(created_coll)
                vl = bpy.context.view_layer
                lc = next((c for c in vl.layer_collection.children if c.collection == created_coll), None)
                if lc: vl.active_layer_collection = lc
                for o in list(bpy.context.selected_objects): o.select_set(False)
                res["collection"] = created_coll.name
            stage = "run"
            cobj, res["compat"] = compile_for_this_blender(code, fname)
            with contextlib.redirect_stdout(tee_out):
                exec(cobj, ns)
            stage = "finish"
            _obj_mode(bpy.context)
            res["viewport_colors"] = solid_colors([m for m in bpy.data.materials if m.as_pointer() not in mats_before])
            bpy.context.view_layer.update()
        res["ok"] = True
    except BaseException as exc:                           # SystemExit / KeyboardInterrupt from pasted code must not kill Blender
        tb = traceback.extract_tb(exc.__traceback__)
        hit = [f for f in tb if f.filename == fname]
        res["line"] = hit[-1].lineno if hit else 0
        res["error"] = "%s: %s" % (type(exc).__name__, str(exc).strip().splitlines()[0][:300] if str(exc).strip() else "")
        res["stage"] = stage
        traceback.print_exc()
        try:
            with context.temp_override(window=win, area=area, region=reg, screen=win.screen):
                _obj_mode(bpy.context)
        except Exception:
            pass
        # roll back the half-built result: demo scene / new collection with the objects made so far
        try:
            if created_scene is not None and created_scene.name in bpy.data.scenes:
                win.scene = orig_scene
                for o in list(created_scene.objects):
                    if o.as_pointer() not in before: bpy.data.objects.remove(o, do_unlink=True)
                bpy.data.scenes.remove(created_scene)
                res["scene"] = ""
            if created_coll is not None and created_coll.name in bpy.data.collections:
                for o in list(created_coll.all_objects):
                    if o.as_pointer() not in before: bpy.data.objects.remove(o, do_unlink=True)
                bpy.data.collections.remove(created_coll)
                res["collection"] = ""
        except Exception:
            traceback.print_exc()
    finally:
        try: prefs_view.use_translate_new_dataname = keep_newdata
        except Exception: pass
        try: os.chdir(old_cwd)
        except Exception: pass
    res["output"] = [l for l in "".join(tee_out.buf).splitlines() if l.strip()][-12:]
    res["new_objects"] = len([o for o in bpy.data.objects if o.as_pointer() not in before])
    if created_coll is not None and res["ok"] and created_coll.name in bpy.data.collections and not created_coll.all_objects and not created_coll.children:
        bpy.data.collections.remove(created_coll); res["collection"] = ""          # code made nothing in it: don't leave an empty collection
    after = _list_files(wd)
    res["files"] = sorted(p for p, m in after.items() if p not in files_before or files_before[p] != m)[:200]
    res["seconds"] = round(time.time() - t0, 2)
    res["ns"] = ns if os.environ.get("BSG_TEST") else None
    LAST.clear(); LAST.update(res)
    return res


def report_result(op, res, title):
    if res["ok"]:
        where = (_t("새 씬 '%s'" % res["scene"], "new scene '%s'" % res["scene"]) if res["scene"] else
                 _t("새 컬렉션 '%s'" % res["collection"], "new collection '%s'" % res["collection"]) if res["collection"] else _t("지금 씬", "current scene"))
        msg = _t("'%s' 완성: %s에 새 오브젝트 %d개 (%.1f초). 되돌리기는 Ctrl+Z." % (title, where, res["new_objects"], res["seconds"]),
                 "Built '%s': %d new objects in %s (%.1f s). Undo with Ctrl+Z." % (title, res["new_objects"], where, res["seconds"]))
        if res["files"]:
            op.report({"INFO"}, _t("파일 %d개를 만들었어요: %s" % (len(res["files"]), res["workdir"]), "Wrote %d files in %s" % (len(res["files"]), res["workdir"])))
        if res.get("viewport_colors"):
            op.report({"INFO"}, _t("새 재질 %d개의 뷰포트 색을 셰이더 색으로 맞췄어요 (Solid 모드에서도 보이게)." % res["viewport_colors"],
                                   "Set the viewport colour of %d new materials from their shader colour (so Solid mode shows them)." % res["viewport_colors"]))
        if res["compat"]:
            op.report({"INFO"}, _t("Blender 4.x용으로 재질 노드를 켜서 실행했어요.", "Ran with material nodes switched on for Blender 4.x."))
        op.report({"INFO"}, msg)
        res["msg"] = msg
    else:
        ln = (_t(" (%d번째 줄)" % res["line"], " (line %d)" % res["line"]) if res["line"] else "")
        msg = _t("'%s' 실행 중 오류%s: %s — 만들던 결과는 지웠어요. 자세한 내용은 Window › Toggle System Console." % (title, ln, res["error"]),
                 "Error while running '%s'%s: %s — the half-built result was removed. Details: Window › Toggle System Console." % (title, ln, res["error"]))
        op.report({"ERROR"}, msg)
        res["msg"] = msg
    LAST["msg"] = res["msg"]


# ------------------------------------------------------------------ operators
def _example_flags(e):
    sc = scan(clip_of(e))
    if e["kind"] == "script" and e.get("setup") and e["setup"] != "empty":
        pass
    return sc


def needs_save_block(op, e):
    if e.get("needs_save") and not bpy.data.filepath:
        op.report({"WARNING"}, _t("'%s'은(는) 저장된 .blend 파일 옆에 복사본을 만드는 예제예요. 먼저 파일을 저장(Ctrl+S)한 뒤 다시 눌러 주세요. 실행하지 않았어요." % ex_title(e),
                                  "'%s' makes a copy next to the saved .blend file. Save the file first (Ctrl+S), then press again. Nothing was run." % ex_title(e)))
        LAST.clear(); LAST.update(id=e["id"], ok=False, msg="needs_save")
        return True
    return False


class BSG_OT_build(bpy.types.Operator):
    """선택한 예제를 사이트와 똑같은 코드로 만들어요 / Build the selected example with exactly the site's code"""
    bl_idname = "script_guide.build"
    bl_label = "Build Example"
    bl_options = {"REGISTER", "UNDO"}

    eid: bpy.props.StringProperty(name="Example", default="", options={"SKIP_SAVE"})
    use_demo: bpy.props.BoolProperty(name="Demo scene", default=True, options={"SKIP_SAVE"})

    @classmethod
    def description(cls, context, properties):
        return _t("사이트에서 '코드 복사'로 복사되는 코드와 똑같은 코드를 실행해요. 스크립트는 사이트의 '실행 전' 그림과 같은 데모 장면을 새 씬에 만든 뒤 실행하고, "
                  "모델링·시작 타입 예제는 새 컬렉션에 만들어요. Ctrl+Z 한 번으로 통째로 되돌릴 수 있어요.",
                  "Runs exactly the code the site's copy button copies. Scripts first get the same demo scene as the site's 'Before' picture, "
                  "built in a new scene; modeling and start-type examples go into a new collection. One Ctrl+Z undoes it all.")

    def execute(self, context):
        data()
        e = _BY_ID.get(self.eid or context.window_manager.bsg_selected)
        if e is None:
            self.report({"ERROR"}, _t("먼저 목록에서 예제를 골라 주세요.", "Pick an example from the list first.")); return {"CANCELLED"}
        vb = version_block(e)
        if vb:
            self.report({"WARNING"}, _t("건너뜀: '%s'은(는) 이 Blender(%s)에서 못 써요 — %s" % (ex_title(e), bpy.app.version_string, vb[0]),
                                        "Skipped: '%s' does not work in this Blender (%s) — %s" % (ex_title(e), bpy.app.version_string, vb[1])))
            LAST.clear(); LAST.update(id=e["id"], ok=False, skipped=True, msg="version")
            return {"CANCELLED"}
        if needs_save_block(self, e):
            return {"CANCELLED"}
        res = build(context, clip_of(e), ex=e, use_demo=self.use_demo, label=e["id"])
        report_result(self, res, ex_title(e))
        return {"FINISHED"}


class BSG_OT_paste(bpy.types.Operator):
    """사이트에서 '코드 복사'한 코드를 클립보드에서 읽어 실행해요 / Run the code copied with the site's copy button"""
    bl_idname = "script_guide.paste"
    bl_label = "Paste from Clipboard & Build"
    bl_options = {"REGISTER", "UNDO"}

    text: bpy.props.StringProperty(name="Code", description="empty = read the clipboard", default="", options={"SKIP_SAVE", "HIDDEN"})
    trust: bpy.props.BoolProperty(name="I checked this code and trust it", default=False, options={"SKIP_SAVE"})
    use_demo: bpy.props.BoolProperty(name="Demo scene", default=True, options={"SKIP_SAVE"})

    @classmethod
    def description(cls, context, properties):
        return _t("사이트의 '코드 복사' 버튼으로 복사한 코드를 붙여넣어 바로 실행해요. 사이트 예제와 글자 하나까지 같으면 그 예제로 알아보고 바로 만들고, "
                  "다른 코드(고친 코드 포함)는 실행 전에 내용을 검사해서 보여 주고 확인을 받아요.",
                  "Pastes and runs code copied with the site's copy button. Code identical to a site example is recognised and built right away; "
                  "any other code (including edited examples) is checked first and only runs after you confirm.")

    def _get(self, context):
        txt = self.text or context.window_manager.clipboard or ""
        return txt.replace("\r\n", "\n").replace("\r", "\n")

    def invoke(self, context, event):
        txt = self._get(context)
        self._txt = txt
        e = match_clip(txt) if txt.strip() else None
        if e is not None or not txt.strip():
            return self.execute(context)
        self._scan = scan(txt)
        if not self._scan["ok"]:
            return self.execute(context)
        self.trust = False
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context):
        sc = getattr(self, "_scan", None) or scan(self._get(context))
        col = self.layout.column(align=True)
        col.label(text=_t("사이트 예제와 다른 코드예요. 파이썬 코드는 컴퓨터에서 무엇이든 할 수 있어요.", "This is not an unchanged site example. Python code can do anything on your computer."), icon="ERROR", translate=False)
        col.label(text=_t("믿을 수 있는 코드일 때만 실행하세요.", "Only run code you trust."), translate=False)
        col.separator()
        k = guess_kind(self._get(context))
        col.label(text=_t("%d줄 · " % sc["lines"], "%d lines · " % sc["lines"]) + (_t("사이트 도우미 함수로 시작함 (고친 예제로 보여요)", "starts with the site's helper functions (looks like an edited example)") if k != "code" else _t("처음 보는 코드", "unknown code")), translate=False)
        if sc["risks"]:
            col.label(text=_t("검사에서 찾은 것:", "Found by the check:"), translate=False)
            for r in risk_lines(sc):
                col.label(text=r, translate=False)
        else:
            col.label(text=_t("검사에서 위험해 보이는 부분은 못 찾았어요 (완벽한 검사는 아니에요).", "The check found nothing risky (it is not a complete check)."), icon="CHECKMARK", translate=False)
        col.separator()
        box = col.box()
        for ln in self._get(context).splitlines()[:8]:
            box.label(text=ln[:90] or " ", translate=False)
        col.separator()
        col.prop(self, "trust", text=_t("코드를 확인했고 믿을 수 있어요", "I checked this code and trust it"), translate=False)
        col.label(text=_t("결과는 새 컬렉션에 만들어지고 Ctrl+Z로 되돌릴 수 있어요.", "Results go into a new collection; Ctrl+Z undoes them."), translate=False)

    def execute(self, context):
        txt = getattr(self, "_txt", None) or self._get(context)
        if not txt.strip():
            self.report({"ERROR"}, _t("클립보드가 비어 있어요. 사이트에서 '코드 복사'를 먼저 눌러 주세요.", "The clipboard is empty. Press 'Copy code' on the site first."))
            LAST.clear(); LAST.update(ok=False, msg="empty"); return {"CANCELLED"}
        if txt.lstrip().startswith("{") and "blender-shader-dict" in txt[:400]:
            self.report({"ERROR"}, _t("쉐이더 사전에서 복사한 노드예요. '쉐이더 사전 붙여넣기' 애드온(Shader Editor › N)으로 붙여넣어 주세요.",
                                      "This was copied from the Shader Dictionary. Paste it with the 'Shader Dictionary Paste' add-on (Shader Editor › N)."))
            LAST.clear(); LAST.update(ok=False, msg="shader"); return {"CANCELLED"}
        e = match_clip(txt)
        if e is not None:
            context.window_manager.bsg_selected = e["id"]
            vb = version_block(e)
            if vb:
                self.report({"WARNING"}, _t("건너뜀: '%s'은(는) 이 Blender(%s)에서 못 써요 — %s" % (ex_title(e), bpy.app.version_string, vb[0]),
                                            "Skipped: '%s' does not work in this Blender (%s) — %s" % (ex_title(e), bpy.app.version_string, vb[1])))
                LAST.clear(); LAST.update(id=e["id"], ok=False, skipped=True, msg="version"); return {"CANCELLED"}
            if needs_save_block(self, e):
                return {"CANCELLED"}
            self.report({"INFO"}, _t("사이트 예제 '%s'(으)로 알아봤어요." % ex_title(e), "Recognised the site example '%s'." % ex_title(e)))
            res = build(context, clip_of(e), ex=e, use_demo=self.use_demo, label=e["id"])
            report_result(self, res, ex_title(e))
            return {"FINISHED"}
        sc = scan(txt)
        if not sc["ok"]:
            self.report({"ERROR"}, _t("파이썬 코드가 아니거나 문법 오류가 있어요 (%d번째 줄: %s). 실행하지 않았어요." % (sc["line"], sc["error"]),
                                      "Not Python code or a syntax error (line %d: %s). Nothing was run." % (sc["line"], sc["error"])))
            LAST.clear(); LAST.update(ok=False, msg="syntax", line=sc["line"]); return {"CANCELLED"}
        if not self.trust:
            self.report({"WARNING"}, _t("사이트 예제와 다른 코드라 확인이 필요해요. 버튼을 다시 눌러 확인 창에서 체크해 주세요. 실행하지 않았어요.",
                                        "This code is not an unchanged site example, so it needs your confirmation. Press the button again and tick the box. Nothing was run."))
            LAST.clear(); LAST.update(ok=False, msg="needs_trust", risks=sorted(sc["risks"])); return {"CANCELLED"}
        k = guess_kind(txt)
        res = build(context, txt, ex=None, kind="code", label="pasted")
        res["risks"] = sorted(sc["risks"])
        report_result(self, res, _t("붙여넣은 코드", "pasted code"))
        return {"FINISHED"}


class BSG_OT_select(bpy.types.Operator):
    """이 예제 고르기 / Select this example"""
    bl_idname = "script_guide.select"
    bl_label = "Select Example"
    bl_options = {"INTERNAL"}
    eid: bpy.props.StringProperty()

    def execute(self, context):
        context.window_manager.bsg_selected = self.eid
        return {"FINISHED"}


class BSG_OT_page(bpy.types.Operator):
    """목록 페이지 넘기기 / Turn the list page"""
    bl_idname = "script_guide.page"
    bl_label = "Page"
    bl_options = {"INTERNAL"}
    step: bpy.props.IntProperty(default=1)

    def execute(self, context):
        wm = context.window_manager
        wm.bsg_page = max(0, wm.bsg_page + self.step)
        return {"FINISHED"}


class BSG_OT_open_text(bpy.types.Operator):
    """예제 코드를 Text Editor에 열어 직접 읽고 고쳐 볼 수 있게 해요 / Open the example code in the Text Editor to read or edit it"""
    bl_idname = "script_guide.open_text"
    bl_label = "Open Code in Text Editor"

    def execute(self, context):
        data(); e = _BY_ID.get(context.window_manager.bsg_selected)
        if e is None:
            return {"CANCELLED"}
        nm = e["id"] + ".py"
        t = bpy.data.texts.get(nm) or bpy.data.texts.new(nm)
        t.from_string(clip_of(e))
        shown = False
        for a in context.window.screen.areas:
            if a.type == "TEXT_EDITOR":
                a.spaces.active.text = t; shown = True; break
        self.report({"INFO"}, _t("'%s' 텍스트를 만들었어요%s." % (nm, "" if shown else " (Scripting 작업 공간의 Text Editor에서 보세요)"),
                                 "Made text '%s'%s." % (nm, "" if shown else " (see it in the Text Editor of the Scripting workspace)")))
        return {"FINISHED"}


class BSG_OT_open_site(bpy.types.Operator):
    """이 예제의 사이트 페이지 열기 (설명·단계 그림) / Open this example's page on the site (explanations, step pictures)"""
    bl_idname = "script_guide.open_site"
    bl_label = "Open on the Website"

    def execute(self, context):
        D = data(); e = _BY_ID.get(context.window_manager.bsg_selected)
        lang = "ko" if _lang() == "KO" else "en"
        h = "" if e is None else ("#scripts/" + e["id"] if e["kind"] == "script" else "#model/ex/" + e["model"] if e["kind"] == "model" else "#model/st/" + e["id"])
        bpy.ops.wm.url_open(url=D["site"] + "?lang=" + lang + h)
        return {"FINISHED"}


# ------------------------------------------------------------------ UI
_ENUM_CACHE = {}


def _kind_items(self, context):
    k = ("kind", _lang())
    if k not in _ENUM_CACHE:
        _ENUM_CACHE[k] = [(x, _t(*KIND[x]), "") for x in ("script", "model", "start")]
    return _ENUM_CACHE[k]


def _cat_items(self, context):
    kind = getattr(self, "bsg_kind", "script")
    k = ("cat", kind, _lang())
    if k not in _ENUM_CACHE:
        D = data()
        _ENUM_CACHE[k] = [("ALL", _t("전체", "All"), "")] + [(c, cat_label(c), "") for c in D["cats"][kind]]
    return _ENUM_CACHE[k]


def _reset_page(self, context):
    self.bsg_page = 0


def filtered(wm):
    D = data()
    q = [w for w in (wm.bsg_search or "").lower().split() if w]
    out = []
    for e in D["examples"]:
        if e["kind"] != wm.bsg_kind: continue
        if wm.bsg_cat not in ("ALL", "") and e["cat"] != wm.bsg_cat: continue
        if q:
            hay = " ".join([e["id"], e["ko"], e["en"], e["dko"], e["den"], cat_label(e["cat"])]).lower()
            if not all(w in hay for w in q): continue
        out.append(e)
    return out


def _wrap(layout, text, width_px, icon="NONE"):
    """wrap text for a label (Korean glyphs count double)."""
    cols = max(18, int(width_px / 7.2))
    lines, cur, w = [], "", 0
    for word in re.split(r"(\s+)", text):
        ww = sum(2 if unicodedata.east_asian_width(ch) in "WF" else 1 for ch in word)
        if w + ww > cols and cur.strip():
            lines.append(cur.strip()); cur, w = "", 0
            if word.isspace(): continue
        cur += word; w += ww
    if cur.strip(): lines.append(cur.strip())
    col = layout.column(align=True)
    for i, l in enumerate(lines):
        col.label(text=l, icon=icon if i == 0 else "NONE", translate=False)
    return col


PAGE = 12


class BSG_PT_main(bpy.types.Panel):
    bl_label = "Script Modeling Guide"
    bl_idname = "BSG_PT_main"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Script Guide"

    def draw_header(self, context):
        self.layout.label(text=_t("스크립트 모델링 가이드", "Script Modeling Guide"), translate=False)

    def draw(self, context):
        wm = context.window_manager
        L = self.layout
        box = L.box(); col = box.column(align=True)
        col.label(text=_t("① 사이트에서 '코드 복사' 클릭", "① Click 'Copy code' on the site"), translate=False)
        col.label(text=_t("② 아래 버튼을 누르면 바로 만들어져요", "② Press the button below to build it"), translate=False)
        r = col.row(); r.scale_y = 1.6
        r.operator(BSG_OT_paste.bl_idname, text=_t("클립보드에서 붙여넣어 만들기", "Paste from Clipboard & Build"), icon="PASTEDOWN", translate=False)
        L.separator()
        L.label(text=_t("또는 예제를 골라 만들기", "Or pick an example"), icon="VIEWZOOM", translate=False)
        L.row().prop(wm, "bsg_kind", expand=True)
        L.prop(wm, "bsg_cat", text="")
        L.prop(wm, "bsg_search", text="", icon="VIEWZOOM", placeholder=_t("검색 (예: 이름, 머그, render)", "Search (e.g. rename, mug, render)")) if bpy.app.version >= (4, 1, 0) else L.prop(wm, "bsg_search", text="", icon="VIEWZOOM")
        items = filtered(wm)
        pages = max(1, (len(items) + PAGE - 1) // PAGE)
        page = min(wm.bsg_page, pages - 1)
        col = L.column(align=True)
        if not items:
            col.label(text=_t("찾는 예제가 없어요.", "No examples found."), translate=False)
        for e in items[page * PAGE:(page + 1) * PAGE]:
            vb = version_block(e)
            op = col.operator(BSG_OT_select.bl_idname, text=ex_title(e), depress=(e["id"] == wm.bsg_selected), translate=False,
                              icon="ERROR" if vb else ("SCRIPT" if e["kind"] == "script" else "MESH_DATA" if e["kind"] == "model" else "OUTLINER_OB_CURVE"))
            op.eid = e["id"]
        r = L.row(align=True)
        a = r.row(align=True); a.enabled = page > 0
        a.operator(BSG_OT_page.bl_idname, text="", icon="TRIA_LEFT").step = -1
        r.label(text=_t("%d / %d쪽 · %d개" % (page + 1, pages, len(items)), "page %d / %d · %d" % (page + 1, pages, len(items))), translate=False)
        b = r.row(align=True); b.enabled = page < pages - 1
        b.operator(BSG_OT_page.bl_idname, text="", icon="TRIA_RIGHT").step = 1


class BSG_PT_selected(bpy.types.Panel):
    bl_label = "Selected Example"
    bl_idname = "BSG_PT_selected"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Script Guide"
    bl_parent_id = "BSG_PT_main"

    def draw_header(self, context):
        self.layout.label(text=_t("고른 예제", "Selected example"), translate=False)

    def draw(self, context):
        wm = context.window_manager
        data(); e = _BY_ID.get(wm.bsg_selected)
        L = self.layout
        if e is None:
            L.label(text=_t("위 목록에서 예제를 눌러 고르세요.", "Click an example in the list above."), translate=False); return
        width = context.region.width if context.region else 300
        L.label(text=ex_title(e, short=True), icon="FILE_SCRIPT" if e["kind"] == "script" else "MESH_DATA", translate=False)
        sub = "%s · %s" % (_t(*KIND[e["kind"]]), cat_label(e["cat"]))
        if e.get("lvl"):
            sub += " · " + data()["lvl"][0 if _lang() == "KO" else 1][e["lvl"]]
        L.label(text=sub, translate=False)
        _wrap(L.box(), _pick(e, "dko"), width - 30)
        vb = version_block(e)
        if vb:
            bx = L.box(); bx.alert = True
            _wrap(bx, _t("이 Blender(%s)에서는 못 만들어요: %s. Blender 5.x에서 써 주세요." % (bpy.app.version_string, vb[0]),
                         "Not available in this Blender (%s): %s. Use Blender 5.x." % (bpy.app.version_string, vb[1])), width - 30, icon="ERROR")
        sc = scan(clip_of(e))
        notes = []
        if e.get("needs_save") and not bpy.data.filepath:
            notes.append(("ERROR", _t("먼저 .blend 파일을 저장해야 해요 (저장한 파일 옆에 복사본을 만들어요).", "Save the .blend file first (it makes a copy next to it).")))
        if e["kind"] == "script" and e.get("setup") and e["setup"] != "empty":
            notes.append(("SCENE_DATA", _t("사이트 '실행 전' 그림과 같은 데모 장면을 새 씬에 만든 뒤 실행해요.", "Builds the site's 'Before' demo scene in a new scene first.")))
        elif e["kind"] == "script":
            notes.append(("SCENE_DATA", _t("빈 새 씬에서 실행해요.", "Runs in a new empty scene.")))
        else:
            notes.append(("OUTLINER_COLLECTION", _t("새 컬렉션에 만들어요 (지금 씬은 그대로).", "Builds into a new collection (your scene stays).")))
        for k in ("file", "render", "data", "net", "system"):
            if k in sc["risks"]:
                if k == "file":
                    wd, tmp = _workdir(e["id"])
                    notes.append(("FILE_FOLDER", _t("파일을 만들어요 → ", "Writes files → ") + (wd if tmp else _t(".blend 파일 폴더", "the .blend folder"))))
                else:
                    notes.append(("INFO", _t(*RISK_TXT[k])))
        for ic, n in notes:
            _wrap(L, n, width - 30, icon=ic)
        if e["kind"] == "script" and e.get("setup") and e["setup"] != "empty":
            L.prop(wm, "bsg_use_demo", text=_t("데모 장면 만들기 (끄면 지금 씬·선택에 바로 실행)", "Make the demo scene (off = run on your scene/selection)"), translate=False)
        r = L.row(); r.scale_y = 1.6; r.enabled = vb is None
        op = r.operator(BSG_OT_build.bl_idname, text=_t("만들기", "Build"), icon="PLAY", translate=False)
        op.eid = e["id"]; op.use_demo = wm.bsg_use_demo or e["kind"] != "script"
        r = L.row(align=True)
        r.operator(BSG_OT_open_text.bl_idname, text=_t("코드 보기", "View code"), icon="TEXT", translate=False)
        r.operator(BSG_OT_open_site.bl_idname, text=_t("사이트에서 보기", "Open on site"), icon="URL", translate=False)


class BSG_PT_result(bpy.types.Panel):
    bl_label = "Last Result"
    bl_idname = "BSG_PT_result"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Script Guide"
    bl_parent_id = "BSG_PT_main"

    def draw_header(self, context):
        self.layout.label(text=_t("마지막 결과", "Last result"), translate=False)

    def draw(self, context):
        L = self.layout
        if not LAST.get("msg"):
            L.label(text=_t("아직 실행한 게 없어요.", "Nothing run yet."), translate=False); return
        width = context.region.width if context.region else 300
        _wrap(L, LAST["msg"], width - 30, icon="CHECKMARK" if LAST.get("ok") else "ERROR")
        out = LAST.get("output") or []
        if out:
            L.label(text=_t("print() 출력:", "print() output:"), translate=False)
            bx = L.box().column(align=True)
            for l in out[-8:]:
                bx.label(text=l[:80], translate=False)


class BSG_Prefs(bpy.types.AddonPreferences):
    bl_idname = __package__ or __name__
    ui_language: bpy.props.EnumProperty(name="Language / 언어", items=[
        ("AUTO", "Auto (Blender) / 자동", "블렌더 인터페이스 언어를 따라가요 / Follow Blender's interface language"),
        ("KO", "한국어", "한국어로 표시"), ("EN", "English", "Show in English")], default="AUTO",
        update=lambda self, ctx: _ENUM_CACHE.clear())

    def draw(self, context):
        self.layout.prop(self, "ui_language")
        D = data()
        self.layout.label(text=_t("예제 %d개 (스크립트 %d · 모델링 %d · 시작 타입 %d) · 사이트 기준 Blender %s",
                                  "%d examples (scripts %d · modeling %d · start types %d) · site made with Blender %s") %
                          (len(D["examples"]), len(D["cats"] and [e for e in D["examples"] if e["kind"] == "script"]),
                           len([e for e in D["examples"] if e["kind"] == "model"]), len([e for e in D["examples"] if e["kind"] == "start"]), D["site_version"]),
                          translate=False)
        wd, tmp = _workdir()
        self.layout.label(text=_t("파일을 쓰는 예제의 폴더: .blend 파일 옆 (저장 전에는 %s 안의 예제별 폴더)" % wd, "Folder for examples that write files: next to the .blend (unsaved: a folder per example in %s)" % wd), translate=False)


CLASSES = (BSG_Prefs, BSG_OT_build, BSG_OT_paste, BSG_OT_select, BSG_OT_page, BSG_OT_open_text, BSG_OT_open_site,
           BSG_PT_main, BSG_PT_selected, BSG_PT_result)

_KO = {
    ("*", "Script Guide"): "스크립트 가이드",
    ("*", "Script Modeling Guide"): "스크립트 모델링 가이드",
    ("Operator", "Build Example"): "예제 만들기",
    ("Operator", "Paste from Clipboard & Build"): "클립보드에서 붙여넣어 만들기",
    ("Operator", "Open Code in Text Editor"): "코드를 Text Editor에 열기",
    ("Operator", "Open on the Website"): "사이트에서 보기",
    ("*", "Demo scene"): "데모 장면",
    ("*", "I checked this code and trust it"): "코드를 확인했고 믿을 수 있어요",
}


def register():
    try:
        bpy.app.translations.register(__name__, {"ko_KR": _KO, "ko": _KO})
    except Exception:
        pass
    for c in CLASSES:
        bpy.utils.register_class(c)
    WM = bpy.types.WindowManager
    WM.bsg_kind = bpy.props.EnumProperty(name="Kind", items=_kind_items, update=lambda s, c: (setattr(s, "bsg_page", 0), setattr(s, "bsg_cat", "ALL")))
    WM.bsg_cat = bpy.props.EnumProperty(name="Category", items=_cat_items, update=_reset_page)
    WM.bsg_search = bpy.props.StringProperty(name="Search", default="", update=_reset_page, options={"TEXTEDIT_UPDATE"})
    WM.bsg_page = bpy.props.IntProperty(default=0, min=0)
    WM.bsg_selected = bpy.props.StringProperty(default="")
    WM.bsg_use_demo = bpy.props.BoolProperty(name="Demo scene", default=True)


def unregister():
    WM = bpy.types.WindowManager
    for p in ("bsg_kind", "bsg_cat", "bsg_search", "bsg_page", "bsg_selected", "bsg_use_demo"):
        try: delattr(WM, p)
        except Exception: pass
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass
